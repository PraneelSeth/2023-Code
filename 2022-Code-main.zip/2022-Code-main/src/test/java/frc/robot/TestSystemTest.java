package frc.robot;

import static org.junit.Assert.*;

import org.junit.*;

/** Class that tests the system test */
public class TestSystemTest {
  @Test
  public void test() {
    // assert statements
    Assert.assertEquals(0, 0);
  }
}
