# FRC-2022

The repository for FRC 6901's 2022 Robot Code.

There are also issues in this repository to track components outside of programming to test the beta Github Projects.

## Formatter Usage

This project uses spotless formatting for code. To automatically format code with spotless, run:
`./gradlew spotlessApply`
